import React from 'react';
import Library from './Components/Library';
import Employee from './Components/Employee';

function App() {
  return (
    <div className="App">
       <Library />
       <br/><br/>
       <Employee />
    </div>
  );
}

export default App;