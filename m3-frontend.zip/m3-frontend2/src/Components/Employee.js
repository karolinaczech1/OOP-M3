import React, { Component } from 'react';
import axios from 'axios';
import {Input, FormGroup, Modal, ModalHeader, ModalBody, ModalFooter, Table, Button, Label } from 'reactstrap';



class App extends Component{
    state = {
        employee: [],
        newEmployeeData: {
          name: '',
          lastName: '',
          position: '',
          email: '',
          phone: ''
        },
        editEmployeeData: {
          id: '',
          name: '',
          lastName: '',
          position: '',
          email: '',
          phone: ''
        },
        newEmployeeModal: false,
        editEmployeeModal: false
      }
   
      componentDidMount() {
       this.refreshEmployee();
      }
   
   
      toggleNewEmployeeModal() {
        this.setState({
          newEmployeeModal: ! this.state.newEmployeeModal
        })
      }
   
      toggleEditEmployeeModal() {
       this.setState({
         editEmployeeModal: ! this.state.editEmployeeModal
       })
     }
   
      addEmployee() {
        axios.post('http://localhost:8080/employee/', this.state.newEmployeeData).then((response) => {
          let { employee } = this.state;
          employee.push(response.data);
          this.setState({ employee, newEmployeeModal:false, newEmployeeData: {
            name: '',
            lastName: '',
            position: '',
            email: '',
            phone: ''
          } });
        });
      }
   
      updateEmployee() {
        let { name, lastName, position, email, phone } = this.state.editEmployeeData;
        axios.put('http://localhost:8080/employee/' + this.state.editEmployeeData.id, {
            name, lastName, position, email, phone
        }).then((response) => {
          this.refreshEmployee();
          this.setState({ editEmployeeModal: false, editEmployeeData: { id: "", name: "", lastName: "", position: "", email: "", phone: "" } })
        });
      }
   
      editEmployee(id, name, lastName, position, email, phone) {
        this.setState({
          editEmployeeData: { id, name, lastName, position, email, phone }, editEmployeeModal: ! this.state.editEmployeeModal
        });
      }
   
   
      refreshEmployee() {
       axios.get('http://localhost:8080/employee/').then((response) =>  {
         this.setState({
           employee: Array.from(response.data._embedded.employee)
         })
       });
      }
   
   
      deleteEmployee(id){
       axios.delete('http://localhost:8080/employee/' + id).then((response) => {
         this.refreshEmployee();
       })
      }
   
     findEmployeeById(){
      let id = document.getElementById("e_id").value;
   
      if(id !== ""){
       axios.get('http://localhost:8080/employee/' + id).then((response) => {
         this.setState({employee: Array(response.data)})
       });
      }else{
        this.refreshEmployee();
      }   
     }
   
     /*findBookByAuthor(){
       let author = document.getElementById("book_id").value;
    
       if(author !== ""){
        axios.get('http://localhost:8080/api/library/findByAuthor/' + author).then((response) => {
          this.setState({books: Array.from(response.data.libraryList)})
        });
       }else{
         this.refreshBooks();
       }   
      }
   
      findBookByStatus(){
       let status = document.getElementById("book_id").value;
    
       if(status !== ""){
        axios.get('http://localhost:8080/api/library/findByStatus/' + status).then((response) => {
          this.setState({books: Array.from(response.data.libraryList)})
        });
       }else{
         this.refreshBooks();
       }   
      }*/
   
   
      render() {
   
        let employees = this.state.employee.map((e) => {
          return (
           <tr key={e.id}>
             <td>{e.id}</td>
             <td>{e.name}</td>
             <td>{e.lastName}</td>
             <td>{e.position}</td>
             <td>{e.email}</td>
             <td>{e.phone}</td>
             <td>
               <Button color="success" size="sm" className="mr-2" onClick={this.editEmployee.bind(this, e.id, e.name, e.lastName, e.position, e.email, e.phone)}>Edit</Button>
               <Button color="danger" size="sm" onClick={this.deleteEmployee.bind(this, e.id)}>Delete</Button>
             </td>
          </tr>
          )
        })
   
        return (
   
          <div className="App container">
            
            <h1 className="mt-2">Employee</h1> <br/>
            <Input className="w-50" type="text" id="e_id"></Input>
            <Button className="my-2" size="sm" onClick={this.findEmployeeById.bind(this)}>Find by Id</Button>    
            <Button className="my-2, mx-2" size="sm" onClick={this.refreshEmployee.bind(this)}>Show all</Button> <br/>
            
            <Button className="my-3" color="primary" onClick={this.toggleNewEmployeeModal.bind(this)}>Add Employee</Button>
            <Modal isOpen={this.state.newEmployeeModal} toggle={this.toggleNewEmployeeModal.bind(this)}>
            <ModalHeader toggle={this.toggleNewEmployeeModal.bind(this)}>Add a new employee</ModalHeader>
            <ModalBody>
   
              <FormGroup>
                 <Label for="name">Name</Label>
                 <Input id="name" value={this.state.newEmployeeData.name} onChange={(e) => {
                   let { newEmployeeData } = this.state;
                   newEmployeeData.name = e.target.value;
                   this.setState({newEmployeeData});
                 }}></Input>
              </FormGroup>
   
              <FormGroup>
                 <Label for="lastName">Last Name</Label>
                 <Input id="lastName" value={this.state.newEmployeeData.lastName} onChange={(e) => {
                   let { newEmployeeData } = this.state;
                   newEmployeeData.lastName = e.target.value;
                   this.setState({newEmployeeData});
                 }}></Input>
              </FormGroup>

              <FormGroup>
                 <Label for="position">Position</Label>
                 <Input id="position" value={this.state.newEmployeeData.position} onChange={(e) => {
                   let { newEmployeeData } = this.state;
                   newEmployeeData.position = e.target.value;
                   this.setState({newEmployeeData});
                 }}></Input>
              </FormGroup>

              <FormGroup>
                 <Label for="email">Email</Label>
                 <Input id="email" value={this.state.newEmployeeData.email} onChange={(e) => {
                   let { newEmployeeData } = this.state;
                   newEmployeeData.email = e.target.value;
                   this.setState({newEmployeeData});
                 }}></Input>
              </FormGroup>

              <FormGroup>
                 <Label for="phone">Phone</Label>
                 <Input id="phone" value={this.state.newEmployeeData.phone} onChange={(e) => {
                   let { newEmployeeData } = this.state;
                   newEmployeeData.phone = e.target.value;
                   this.setState({newEmployeeData});
                 }}></Input>
              </FormGroup>
   

   
            </ModalBody>
            <ModalFooter>
             <Button color="primary" onClick={this.addEmployee.bind(this)}>Add Employee</Button>
             <Button color="secondary" onClick={this.toggleNewEmployeeModal.bind(this)}>Cancel</Button>
            </ModalFooter>
            </Modal>
   
   
   
   
   
            <Modal isOpen={this.state.editEmployeeModal} toggle={this.toggleEditEmployeeModal.bind(this)}>
            <ModalHeader toggle={this.toggleEditEmployeeModal.bind(this)}>Edit employee</ModalHeader>
            <ModalBody>
   
            
              <FormGroup>
                 <Label for="id">ID</Label>
                 <Input id="id" value={this.state.editEmployeeData.id} onChange={(e) => {
                   let { editEmployeeData } = this.state;
                   editEmployeeData.id = e.target.value;
                   this.setState({editEmployeeData});
                 }}></Input>
              </FormGroup>

              <FormGroup>
                 <Label for="name">Name</Label>
                 <Input id="name" value={this.state.editEmployeeData.name} onChange={(e) => {
                   let { editEmployeeData } = this.state;
                   editEmployeeData.name = e.target.value;
                   this.setState({editEmployeeData});
                 }}></Input>
              </FormGroup>
   
              <FormGroup>
                 <Label for="lastName">Last Name</Label>
                 <Input id="lastName" value={this.state.editEmployeeData.lastName} onChange={(e) => {
                   let { editEmployeeData } = this.state;
                   editEmployeeData.lastName = e.target.value;
                   this.setState({editEmployeeData});
                 }}></Input>
              </FormGroup>

              <FormGroup>
                 <Label for="position">Position</Label>
                 <Input id="position" value={this.state.editEmployeeData.position} onChange={(e) => {
                   let { editEmployeeData } = this.state;
                   editEmployeeData.position = e.target.value;
                   this.setState({editEmployeeData});
                 }}></Input>
              </FormGroup>

              <FormGroup>
                 <Label for="email">Email</Label>
                 <Input id="email" value={this.state.editEmployeeData.email} onChange={(e) => {
                   let { editEmployeeData } = this.state;
                   editEmployeeData.email = e.target.value;
                   this.setState({editEmployeeData});
                 }}></Input>
              </FormGroup>

              <FormGroup>
                 <Label for="phone">Phone</Label>
                 <Input id="phone" value={this.state.editEmployeeData.phone} onChange={(e) => {
                   let { editEmployeeData } = this.state;
                   editEmployeeData.phone = e.target.value;
                   this.setState({editEmployeeData});
                 }}></Input>
              </FormGroup>
   
              
   
            </ModalBody>
            <ModalFooter>
             <Button color="primary" onClick={this.updateEmployee.bind(this)}>Edit Employee</Button>
             <Button color="secondary" onClick={this.toggleEditEmployeeModal.bind(this)}>Cancel</Button>
            </ModalFooter>
            </Modal>
   
   
   
   
   
            <Table>          
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Last Name</th>
                  <th>Position</th>
                  <th>Email</th>
                  <th>Phone</th>
                </tr>         
              </thead>
   
              <tbody>
                 {employees}
              </tbody>
            </Table>
            <br/><br/><br/>
   
          </div>
   
        );
   
      }
   
   }
   
   export default App;