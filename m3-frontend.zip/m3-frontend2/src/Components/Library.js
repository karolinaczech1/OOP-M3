import React, { Component } from 'react';
import axios from 'axios';
import {Input, FormGroup, Modal, ModalHeader, ModalBody, ModalFooter, Table, Button, Label } from 'reactstrap';



class App extends Component{
    state = {
        books: [],
        newBookData: {
          title: '',
          author: '',
          status: ''
        },
        editBookData: {
         id: '',
         title: '',
         author: '',
         status: ''
       },
        newBookModal: false,
        editBookModal: false
      }
   
      componentDidMount() {
       this.refreshBooks();
      }
   
   
      toggleNewBookModal() {
        this.setState({
          newBookModal: ! this.state.newBookModal
        })
      }
   
      toggleEditBookModal() {
       this.setState({
         editBookModal: ! this.state.editBookModal
       })
     }
   
      addBook() {
        axios.post('http://localhost:8080/api/library/', this.state.newBookData).then((response) => {
          let { books } = this.state;
          books.push(response.data);
          this.setState({ books, newBookModal:false, newBookData: {
            title: "",
            author: "",
            status: ""
          } });
        });
      }
   
      updateBook() {
        let { title, author, status } = this.state.editBookData;
        axios.put('http://localhost:8080/api/library/' + this.state.editBookData.id, {
          title, author, status
        }).then((response) => {
          this.refreshBooks();
          this.setState({ editBookModal: false, editBookData: { id: "", title: "", author: "", status: "" } })
        });
      }
   
      editBook(id, title, author, status) {
        this.setState({
          editBookData: { id, title, author, status }, editBookModal: ! this.state.editBookModal
        });
      }
   
   
      refreshBooks() {
       axios.get('http://localhost:8080/api/library/').then((response) =>  {
         this.setState({
           books: Array.from(response.data.libraryList)
         })
       });
      }
   
   
      deleteBook(id){
       axios.delete('http://localhost:8080/api/library/' + id).then((response) => {
         this.refreshBooks();
       })
      }
   
     findBookById(){
      let id = document.getElementById("book_id").value;
   
      if(id !== ""){
       axios.get('http://localhost:8080/api/library/' + id).then((response) => {
         this.setState({books: Array(response.data)})
       });
      }else{
        this.refreshBooks();
      }   
     }
   
     findBookByAuthor(){
       let author = document.getElementById("book_id").value;
    
       if(author !== ""){
        axios.get('http://localhost:8080/api/library/findByAuthor/' + author).then((response) => {
          this.setState({books: Array.from(response.data.libraryList)})
        });
       }else{
         this.refreshBooks();
       }   
      }
   
      findBookByStatus(){
       let status = document.getElementById("book_id").value;
    
       if(status !== ""){
        axios.get('http://localhost:8080/api/library/findByStatus/' + status).then((response) => {
          this.setState({books: Array.from(response.data.libraryList)})
        });
       }else{
         this.refreshBooks();
       }   
      }
   
   
      render() {
   
        let books = this.state.books.map((book) => {
          return (
           <tr key={book.id}>
             <td>{book.id}</td>
             <td>{book.title}</td>
             <td>{book.author}</td>
             <td>{book.status}</td>
             <td>
               <Button color="success" size="sm" className="mr-2" onClick={this.editBook.bind(this, book.id, book.title, book.author, book.status)}>Edit</Button>
               <Button color="danger" size="sm" onClick={this.deleteBook.bind(this, book.id)}>Delete</Button>
             </td>
          </tr>
          )
        })
   
        return (
   
          <div className="App container">
            
            <h1 className="mt-2">Library</h1> <br/>
            <Input className="w-50" type="text" id="book_id"></Input>
            <Button className="my-2" size="sm" onClick={this.findBookById.bind(this)}>Find by Id</Button> 
            <Button className="my-2, mx-2" size="sm" onClick={this.findBookByAuthor.bind(this)}>Find by author</Button> 
            <Button className="my-2, mx-2" size="sm" onClick={this.findBookByStatus.bind(this)}>Find by status</Button>
            <Button className="my-2, mx-2" size="sm" onClick={this.refreshBooks.bind(this)}>Show all</Button> <br/>
            
            <Button className="my-3" color="primary" onClick={this.toggleNewBookModal.bind(this)}>Add Book</Button>
            <Modal isOpen={this.state.newBookModal} toggle={this.toggleNewBookModal.bind(this)}>
            <ModalHeader toggle={this.toggleNewBookModal.bind(this)}>Add a new book</ModalHeader>
            <ModalBody>
   
              <FormGroup>
                 <Label for="title">Title</Label>
                 <Input id="title" value={this.state.newBookData.title} onChange={(e) => {
                   let { newBookData } = this.state;
                   newBookData.title = e.target.value;
                   this.setState({newBookData});
                 }}></Input>
              </FormGroup>
   
              <FormGroup>
                 <Label for="author">Author</Label>
                 <Input id="author" value={this.state.newBookData.author} onChange={(e) => {
                   let { newBookData } = this.state;
                   newBookData.author = e.target.value;
                   this.setState({newBookData});
                 }}></Input>
              </FormGroup>
   
              <FormGroup>
                 <Label for="status">Status</Label>
                 <Input id="status" value={this.state.newBookData.status} onChange={(e) => {
                   let { newBookData } = this.state;
                   newBookData.status = e.target.value;
                   this.setState({newBookData});
                 }}></Input>
              </FormGroup>
   
            </ModalBody>
            <ModalFooter>
             <Button color="primary" onClick={this.addBook.bind(this)}>Add Book</Button>
             <Button color="secondary" onClick={this.toggleNewBookModal.bind(this)}>Cancel</Button>
            </ModalFooter>
            </Modal>
   
   
   
   
   
            <Modal isOpen={this.state.editBookModal} toggle={this.toggleEditBookModal.bind(this)}>
            <ModalHeader toggle={this.toggleEditBookModal.bind(this)}>Edit a new book</ModalHeader>
            <ModalBody>
   
            
              <FormGroup>
                 <Label for="id">ID</Label>
                 <Input id="id" value={this.state.editBookData.id} onChange={(e) => {
                   let { editBookData } = this.state;
                   editBookData.id = e.target.value;
                   this.setState({editBookData});
                 }}></Input>
              </FormGroup>
   
              <FormGroup>
                 <Label for="title">Title</Label>
                 <Input id="title" value={this.state.editBookData.title} onChange={(e) => {
                   let { editBookData } = this.state;
                   editBookData.title = e.target.value;
                   this.setState({editBookData});
                 }}></Input>
              </FormGroup>
   
              <FormGroup>
                 <Label for="author">Author</Label>
                 <Input id="author" value={this.state.editBookData.author} onChange={(e) => {
                   let { editBookData } = this.state;
                   editBookData.author = e.target.value;
                   this.setState({editBookData});
                 }}></Input>
              </FormGroup>
   
              <FormGroup>
                 <Label for="status">Status</Label>
                 <Input id="status" value={this.state.editBookData.status} onChange={(e) => {
                   let { editBookData } = this.state;
                   editBookData.status = e.target.value;
                   this.setState({editBookData});
                 }}></Input>
              </FormGroup>
   
            </ModalBody>
            <ModalFooter>
             <Button color="primary" onClick={this.updateBook.bind(this)}>Edit Book</Button>
             <Button color="secondary" onClick={this.toggleEditBookModal.bind(this)}>Cancel</Button>
            </ModalFooter>
            </Modal>
   
   
   
   
   
            <Table>          
              <thead>
                <tr>
                  <th>#</th>
                  <th>Title</th>
                  <th>Author</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>         
              </thead>
   
              <tbody>
                 {books}
              </tbody>
            </Table>
   
          </div>
   
        );
   
      }
   
   }
   
   export default App;